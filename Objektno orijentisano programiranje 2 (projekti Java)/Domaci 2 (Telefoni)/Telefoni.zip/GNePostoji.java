package gui;

public class GNePostoji extends Exception {

}
